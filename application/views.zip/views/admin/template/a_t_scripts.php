
<!-- JQUERY -->
<script type="text/javascript" src="<?=base_url()?>assets/js/jquery-3.6.0.min.js"></script>
<!-- BOOTSTRAP -->
<script type="text/javascript" src="<?=base_url()?>assets/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js"></script>
<!-- DATATABLES -->
<script type="text/javascript" src="<?=base_url()?>assets/js/datatables.min.js"></script>

<script type="text/javascript" src="<?=base_url()?>assets/mdb.min.js"></script>

<script type="text/javascript" src="<?=base_url()?>assets/js/admin.js"></script>